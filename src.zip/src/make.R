# R make file, main controller to source data
# induction and dataframe set up

source("./src/get_email_data.R")
source("./src/create_df.R")
